export const VALIDATOR_URL = 'http://34.187.154.219:48888';
export const EVENT_POLL_INTERVAL_MINUTES = 1;

export const FAKE_MONEY = false;
export const TEST_MODE = false;
export const HL_API_URL = TEST_MODE ? "https://api.hyperliquid-testnet.xyz" : "https://api.hyperliquid.xyz";
export const HL_APP_URL = TEST_MODE ? "https://app.hyperliquid-testnet.xyz" : "https://app.hyperliquid.xyz";
